﻿using System;
using System.IO;

namespace MasemolaDamaris_4466914_VRA704_Assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            { while (true) //
                { 
                    Console.WriteLine("Choose a function:"); 
                    Console.WriteLine("1. Addition"); 
                    Console.WriteLine("2. Subtraction");
                    Console.WriteLine("3. Multiplication");
                    Console.WriteLine("4. Division"); 
                    Console.WriteLine("5. Square Root"); 
                    Console.WriteLine("6. Exponent");
                    Console.WriteLine("7. Exit");

                    Console.Write("Enter your choice (1-7): ");
                    string choice = Console.ReadLine();

                    switch (choice) //We use switch because we have a selection of posibilities, the condition is compared with the value of the case
                    { 
                        case "1": Addition(); //The addition will be executed 
                            break; //This is used to exit the switch block 
                        case "2": Subtraction(); 
                            break; 
                        case "3": Multiplication(); 
                            break; 
                        case "4": Division(); 
                            break;
                        case "5": SquareRoot(); 
                            break; 
                        case "6": Exponent();
                            break;
                        case "7": Console.WriteLine("Exiting..."); 
                            return; 
                        default: Console.WriteLine("Error");
                            break;
                    } 
                }
            }
            static void Addition() 
            {
                Console.WriteLine("Enter a number:"); 
                double num1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter another number:");
                double num2 = Convert.ToDouble(Console.ReadLine()); //
                Console.WriteLine($"Result: {num1 + num2}"); //The dollar sign is used to look for variables within these {} brackets
            }
            static void Subtraction() 
            { 
                Console.WriteLine("Enter a number:"); 
                double num1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter another number:");
                double num2 = Convert.ToDouble(Console.ReadLine()); 
                Console.WriteLine($"Result: {num1 - num2}"); //The dollar sign is used to look for variables within these {} brackets
            }
            static void Multiplication()
            { 
                Console.WriteLine("Enter a number:"); 
                double num1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter another number:");
                double num2 = Convert.ToDouble(Console.ReadLine()); 
                Console.WriteLine($"Result: {num1 * num2}"); //The dollar sign is used to look for variables within these {} brackets
            }
            static void Division() 
            { 
                Console.WriteLine("Enter a number:"); 
                double num1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter another number:");
                double num2 = Convert.ToDouble(Console.ReadLine()); 
                double result = num1 / num2; double remainder = num1 % num2; 
                Console.WriteLine($"Result: {Math.Floor(result)} remainder {remainder}"); 
            }
            static void SquareRoot() 
            { 
                Console.WriteLine("Enter a number:"); 
                double num = Convert.ToDouble(Console.ReadLine());
                double result = Math.Sqrt(num);
                Console.WriteLine($"Result: {Math.Floor(result)}"); 
            }
            static void Exponent()
            { 
                Console.WriteLine("Enter base number:"); 
                double num1 = Convert.ToDouble(Console.ReadLine()); 
                Console.WriteLine("Enter exponent:"); 
                double num2 = Convert.ToDouble(Console.ReadLine()); 
                Console.WriteLine($"Result: {Math.Pow(num1, num2)}"); 
            }
            static double GetNum(string message)
            {
                double num= 0;
                while(true)
                {
                    Console.Write(message);
                    string input = Console.ReadLine();
                    if (double.TryParse(input, out num))
                    {
                        return num;
                    }
                    else { Console.WriteLine("Error, Please insert a valid number");
                    }
                }
            }
        }
    }
}
